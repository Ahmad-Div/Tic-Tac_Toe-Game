import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class TicTacToe extends JFrame implements ActionListener {

    JFrame jFrame = new JFrame("Tic-Tac-Toe Game");
    JPanel upperPanel = new JPanel();
    JPanel gamePanel = new JPanel();
    JPanel underPanel = new JPanel();
    JLabel upperPanelLabel = new JLabel();
    JLabel underPanelLabel = new JLabel();
    JButton[] jButtons = new JButton[9];
    ImageIcon imageIcon = new ImageIcon("img_1.png");
    boolean player1_turn = true;

    public TicTacToe() {

        //The frame
        jFrame.setSize(900, 800);
        jFrame.setIconImage(imageIcon.getImage());
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.getContentPane().setBackground(Color.BLACK); // I must use getContentPane().set
        jFrame.setVisible(true);
        jFrame.setResizable(false);
        jFrame.setLayout(new BorderLayout());
        jFrame.add(upperPanel, BorderLayout.NORTH);
        jFrame.add(underPanel, BorderLayout.SOUTH);
        jFrame.add(gamePanel);


        //The upper panel

        upperPanel.setBounds(0, 0, 900, 100);
        upperPanel.setLayout(new BorderLayout());
        upperPanel.add(upperPanelLabel);

        //The upper panel label

        upperPanelLabel.setText("Tic-Tac-Toe");
        upperPanelLabel.setBackground(Color.cyan);
        upperPanelLabel.setFont(new Font("Tapestry", Font.BOLD, 45));
        upperPanelLabel.setForeground(Color.black);
        upperPanelLabel.setHorizontalAlignment(JLabel.CENTER);
        upperPanelLabel.setOpaque(true);


        //The under panel

        underPanel.setBounds(0, 800, 900, 100);
        underPanel.setLayout(new BorderLayout());
        underPanel.add(underPanelLabel);

        //The under panel label

        underPanelLabel.setText("Developer: Ahmad Software");
        underPanelLabel.setBackground(Color.cyan);
        underPanelLabel.setFont(new Font("Tapestry", Font.BOLD, 45));
        underPanelLabel.setForeground(Color.BLACK);
        underPanelLabel.setOpaque(true);
        underPanelLabel.setHorizontalAlignment(JLabel.CENTER);


        //The game panel

        gamePanel.setLayout(new GridLayout(3, 3));

        //Adding the buttons

        for (int i = 0; i < jButtons.length; i++) {
            jButtons[i] = new JButton();
            jButtons[i].setEnabled(true);
            jButtons[i].setSize(200, 200);
            jButtons[i].addActionListener(this);
            jButtons[i].setFocusable(false);
            jButtons[i].setFont(new Font("Tapestry", Font.BOLD, 120));
            gamePanel.add(jButtons[i]);
            firstTurn();
        }


    }

    public void firstTurn() {
        Random random = new Random();
        if (random.nextInt(2) == 0) {
            upperPanelLabel.setText("X turn");
            player1_turn = true;
        } else {
            upperPanelLabel.setText("O turn");
            player1_turn = false;
        }
    }

    public void check() {

        //if x wins
        if (jButtons[0].getText().equals("X") && jButtons[1].getText().equals("X") && jButtons[2].getText().equals("X")) {
            xWins(0, 1, 2);
        }
        if (jButtons[0].getText().equals("X") && jButtons[4].getText().equals("X") && jButtons[8].getText().equals("X")) {
            xWins(0, 4, 8);
        }
        if (jButtons[1].getText().equals("X") && jButtons[4].getText().equals("X") && jButtons[7].getText().equals("X")) {
            xWins(0, 4, 7);
        }
        if (jButtons[2].getText().equals("X") && jButtons[4].getText().equals("X") && jButtons[6].getText().equals("X")) {
            xWins(2, 4, 6);
        }
        if (jButtons[3].getText().equals("X") && jButtons[4].getText().equals("X") && jButtons[5].getText().equals("X")) {
            xWins(3, 4, 5);
        }
        if (jButtons[6].getText().equals("X") && jButtons[7].getText().equals("X") && jButtons[8].getText().equals("X")) {
            xWins(6, 7, 8);
        }
        if (jButtons[0].getText().equals("X") && jButtons[3].getText().equals("X") && jButtons[6].getText().equals("X")) {
            xWins(0, 3, 6);
        }
        if (jButtons[1].getText().equals("X") && jButtons[4].getText().equals("X") && jButtons[7].getText().equals("X")) {
            xWins(1, 4, 7);
        }
        if (jButtons[2].getText().equals("X") && jButtons[5].getText().equals("X") && jButtons[8].getText().equals("X")) {
            xWins(2, 5, 8);
        }


        //if o wins

        if (jButtons[0].getText().equals("O") && jButtons[1].getText().equals("O") && jButtons[2].getText().equals("O")) {
            oWins(0, 1, 2);
        }
        if (jButtons[0].getText().equals("O") && jButtons[4].getText().equals("O") && jButtons[8].getText().equals("O")) {
            oWins(0, 4, 8);
        }
        if (jButtons[1].getText().equals("O") && jButtons[4].getText().equals("O") && jButtons[7].getText().equals("O")) {
            oWins(0, 4, 7);
        }
        if (jButtons[2].getText().equals("O") && jButtons[4].getText().equals("O") && jButtons[6].getText().equals("O")) {
            oWins(2, 4, 6);
        }
        if (jButtons[3].getText().equals("O") && jButtons[4].getText().equals("O") && jButtons[5].getText().equals("O")) {
            oWins(3, 4, 5);
        }
        if (jButtons[6].getText().equals("O") && jButtons[7].getText().equals("O") && jButtons[8].getText().equals("O")) {
            oWins(6, 7, 8);
        }
        if (jButtons[0].getText().equals("O") && jButtons[3].getText().equals("O") && jButtons[6].getText().equals("O")) {
            oWins(0, 3, 6);
        }
        if (jButtons[1].getText().equals("O") && jButtons[4].getText().equals("O") && jButtons[7].getText().equals("O")) {
            oWins(1, 4, 7);
        }
        if (jButtons[2].getText().equals("O") && jButtons[5].getText().equals("O") && jButtons[8].getText().equals("O")) {
            oWins(2, 5, 8);
        }
    }

    public void xWins(int a, int b, int c) {
        jButtons[a].setBackground(Color.magenta);
        jButtons[b].setBackground(Color.magenta);
        jButtons[c].setBackground(Color.magenta);
        for (int i = 0; i < jButtons.length; i++) {
            jButtons[i].setEnabled(false);
        }
        upperPanelLabel.setText("X wins");
    }

    public void oWins(int a, int b, int c) {
        jButtons[a].setBackground(Color.magenta);
        jButtons[b].setBackground(Color.magenta);
        jButtons[c].setBackground(Color.magenta);
        for (int i = 0; i < jButtons.length; i++) {
            jButtons[i].setEnabled(false);
        }
        upperPanelLabel.setText("O wins");
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        for (int i = 0; i < jButtons.length; i++) {
            if (e.getSource() == jButtons[i]) {
                if (player1_turn) {
                    if (jButtons[i].getText().equals("")) {
                        jButtons[i].setText("X");
                        jButtons[i].setForeground(Color.BLUE);
                        player1_turn = false;
                        upperPanelLabel.setText("O turn");
                        check();
                    }
                } else {
                    if (jButtons[i].getText().equals("")) {
                        jButtons[i].setText("O");
                        jButtons[i].setForeground(Color.BLUE);
                        player1_turn = true;
                        upperPanelLabel.setText("X turn");
                        check();
                    }
                }
            }
        }
    }
}
